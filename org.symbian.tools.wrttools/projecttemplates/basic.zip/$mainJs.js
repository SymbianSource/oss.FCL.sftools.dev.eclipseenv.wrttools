/*
 * JavaScript file
 */

function init()
{
	// TODO Add your code here
}
