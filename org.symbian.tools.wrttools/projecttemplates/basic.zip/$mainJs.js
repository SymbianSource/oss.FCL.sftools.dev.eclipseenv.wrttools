/*
 * JavaScript file
 */

function init()
{
	//	Add your code here
}
